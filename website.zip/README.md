# My Website

## File Structure

```
my-website/
│
├── index.html              ← main page (edit content here)
│
├── css/
│   ├── main.css            ← colours, fonts, layout (start here)
│   ├── animations.css      ← ball styling + scroll fade-ins
│   └── responsive.css      ← mobile/tablet breakpoints
│
├── js/
│   ├── ball.js             ← rolling ball logic (config at top of file)
│   └── main.js             ← nav + general interactions
│
├── assets/
│   ├── images/             ← put ball.png and other images here
│   ├── fonts/              ← self-hosted fonts go here
│   └── video/              ← any video files
│
└── README.md               ← this file
```

## Quickstart

1. Drop your ball image into `assets/images/ball.png`
2. Open `js/ball.js` and set `BALL_SIZE` to match your image dimensions
3. Edit content in `index.html`
4. Adjust colours and fonts in `css/main.css` (change the `:root` variables)

## Changing the Ball Config

Open `js/ball.js` — all settings are at the top:

| Setting | What it does |
|---|---|
| `BALL_SIZE` | Match to your image size in px |
| `LEFT_X` | Horizontal % for left-side resting position |
| `RIGHT_X` | Horizontal % for right-side resting position |
| `EXIT_DIST` | How far off-screen ball rolls (px) |
| `SMOOTHNESS` | 0.04 = floaty, 0.15 = snappy |
| `ROLL_SPEED` | How fast ball rotates per pixel moved |

To add a new section, add a line to the `SECTIONS` array in `ball.js`:
```js
{ id: '#your-section-id', xPercent: 30, yPercent: 50, exitTo: 'left' },
```
And add a matching `id` to the section in `index.html`.

## Deploying to GitHub Pages

1. Push to GitHub
2. Go to repo → Settings → Pages
3. Source: Deploy from branch → main → / (root)
4. Live at: `https://YOUR-USERNAME.github.io/my-website`

## Collaborating

To add a collaborator:
- GitHub repo → Settings → Collaborators → Add people

Branch workflow:
```bash
git checkout -b feature-name   # create a branch
git add .
git commit -m "what you changed"
git push origin feature-name   # push branch
# then open a Pull Request on GitHub
```
